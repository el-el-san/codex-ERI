// Aggregates all former standalone integration tests as modules.
mod initialize;
mod progress_notification;
