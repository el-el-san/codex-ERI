// Aggregates all former standalone integration tests as modules.
mod apply_command_e2e;
