// Aggregates all former standalone integration tests as modules.
mod device_code_login;
mod login_server_e2e;
