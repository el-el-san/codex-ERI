// Single integration test binary that aggregates all test modules.
// The submodules live in `tests/suite/`.
mod suite;

mod event_processor_with_json_output;
