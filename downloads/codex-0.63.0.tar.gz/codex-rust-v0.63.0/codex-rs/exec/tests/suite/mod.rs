// Aggregates all former standalone integration tests as modules.
mod add_dir;
mod apply_patch;
mod auth_env;
mod originator;
mod output_schema;
mod resume;
mod sandbox;
mod server_error_exit;
