The changelog can be found on the [releases page](https://github.com/openai/codex/releases).
